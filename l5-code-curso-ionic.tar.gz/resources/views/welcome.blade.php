@extends('admin')

@section('titleLeft')
	Welcome!
@endsection

@section('titlePainel')
	Welcome to Laravel 5.1!
@endsection
	
@section('content')

    <div class="content">
        <div class="title">Laravel 5</div>
    </div>

@endsection